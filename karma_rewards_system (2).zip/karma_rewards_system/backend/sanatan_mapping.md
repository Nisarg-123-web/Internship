## How This System Aligns with Sanatan Dharma

1. **Rooted in Karma Theory:**
   - Every action is tracked and rewarded with *PunyaPoints*, echoing karmic accumulation.

2. **Seva & Yajña Integration:**
   - Peer mentoring, satsang, and feedback mimic selfless service and learning as Yajña.

3. **Ashrama Mapping:**
   - Karma ranks align with Brahmacharya (student) to Rishi (realized teacher).

4. **Tokenomics & Web3 Alignment:**
   - DharmaPoints can be modular ERC tokens connected to BH ecosystem or used for unlocking NFT-based spiritual achievements.

5. **Boosting Engagement:**
   - Leaderboards and ranks (like "Acharya", "Upadhyaya") encourage ethical gamification in UniGuru/Gurukul.