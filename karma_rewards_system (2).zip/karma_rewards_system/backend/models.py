class User:
    def __init__(self, username):
        self.username = username
        self.karma_points = 0
        self.history = []

    def perform_action(self, action, karma_awarded):
        self.karma_points += karma_awarded
        self.history.append({"action": action, "karma": karma_awarded})

    def get_summary(self):
        return {
            "username": self.username,
            "karma_points": self.karma_points,
            "history": self.history,
        }