def calculate_karma(action: str) -> int:
    karma_chart = {
        "complete_course": 100,
        "mentor_peer": 80,
        "submit_assignment": 60,
        "attend_satsang": 50,
        "ask_question": 30,
        "give_feedback": 20,
        "practice_silence": 10,
    }
    return karma_chart.get(action, 0)

def suggest_rank(total_karma: int) -> str:
    if total_karma <1000 and total_karma>=750:
        return "Rishi"
    elif total_karma < 750 and total_karma>=500:
        return "Acharya"
    elif total_karma <500 and total_karma>=300:
        return "Upadhyaya"
    elif total_karma < 300 and total_karma>=200:
        return "Shishya"
    else:
        return "Adhikari"