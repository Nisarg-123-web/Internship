from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import joblib
import numpy as np


app = Flask(__name__, static_folder="frontend")
CORS(app)
model = joblib.load("karma_rank_model.pkl")
label_encoder = joblib.load("rank_label_encoder.pkl")


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.karma_points = 0
        self.history = []

    def perform_action(self, action, karma):
        self.karma_points += karma
        self.history.append({"action": action, "karma": karma})

    def get_summary(self):
        return {
            "username": self.username,
            "karma_points": self.karma_points,
            "history": self.history
        }

users = {}

karma_values = {
    "Complete Course": 50,
    "Mentor Peer": 30,
    "Submit Assignment": 40,
    "Attend Satsang": 20,
    "Ask Question": 10,
    "Give Feedback": 15,
    "Practice Silence": 25
}

def calculate_karma(action):
    return karma_values.get(action, 0)

@app.route("/register", methods=["POST"])
def register():
    data = request.json
    username = data.get("username")
    password = data.get("password")
    if username in users:
        return jsonify({"error": "Username already exists."}), 400
    users[username] = User(username, password)
    return jsonify({"message": "User registered successfully."})

@app.route("/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")
    user = users.get(username)
    if user and user.password == password:
        return jsonify({"message": "Login successful."})
    return jsonify({"error": "Invalid credentials."}), 401

@app.route("/perform_action", methods=["POST"])
def perform_action():
    data = request.json
    username = data.get("username")
    action = data.get("action")

    if username not in users:
        return jsonify({"error": "User not found."}), 404

    karma = calculate_karma(action)
    users[username].perform_action(action, karma)

    return jsonify({
        "message": f"Action '{action}' recorded for {username}",
        "karma_awarded": karma,
        "total_karma": users[username].karma_points
    })

@app.route("/summary/<username>")
def summary(username):
    user = users.get(username)
    if user:
        return jsonify(user.get_summary())
    return jsonify({"error": "User not found"}), 404

@app.route("/")
def serve_index():
    return send_from_directory("frontend", "index.html")

@app.route("/predict_rank", methods=["POST"])
def predict_rank():
    data = request.json
    try:
        features = [
            data["complete_course"],
            data["mentor_peer"],
            data["submit_assignment"],
            data["attend_satsang"],
            data["ask_question"],
            data["give_feedback"],
            data["practice_silence"]
        ]
        input_array = np.array([features])
        predicted = model.predict(input_array)
        rank = label_encoder.inverse_transform(predicted)[0]

        return jsonify({
            "predicted_rank": rank,
            "input": features
        })
    except KeyError as e:
        return jsonify({"error": f"Missing field: {str(e)}"}), 400


if __name__ == "__main__":
    app.run(debug=True)
