const API_BASE = "http://127.0.0.1:5000";

async function register() {
    const username = document.getElementById("regUsername").value.trim();
    const password = document.getElementById("regPassword").value.trim();
    if (!username || !password) return Swal.fire("Please enter username and password.");

    const res = await fetch(`${API_BASE}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
    });

    const data = await res.json();
    if (res.ok) {
        Swal.fire("Registered successfully!");
    } else {
        Swal.fire("Error", data.error || "Something went wrong", "error");
    }
}

async function login() {
    const username = document.getElementById("loginUsername").value.trim();
    const password = document.getElementById("loginPassword").value.trim();
    if (!username || !password) return Swal.fire("Please enter username and password.");

    const res = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
    });

    const data = await res.json();
    if (res.ok) {
        Swal.fire("Login successful!");
        document.getElementById("username").value = username;
    } else {
        Swal.fire("Login failed", data.error || "Invalid credentials", "error");
    }
}

async function performAction() {
    const username = document.getElementById("username").value.trim();
    const action = document.getElementById("action").value;
    if (!username) return Swal.fire("Please enter your username.");

    const res = await fetch(`${API_BASE}/perform_action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, action })
    });

    const data = await res.json();
    if (res.ok) {
        Swal.fire(`Karma +${data.karma_awarded}`, data.message, "success");
        updateSummary(username);
    } else {
        Swal.fire("Error", data.error || "Failed to perform action", "error");
    }
}

async function updateSummary(username) {
    const res = await fetch(`${API_BASE}/summary/${username}`);
    const data = await res.json();

    if (res.ok) {
        let html = `
      <p><strong>Karma Points:</strong> ${data.karma_points}</p>
      <p><strong>Actions:</strong></p>
      <ul>
        ${data.history.map(h => `<li>${h.action} → ${h.karma}</li>`).join("")}
      </ul>
    `;
    document.getElementById("summary").innerHTML = html;
  } else {
    document.getElementById("summary").innerHTML = "<p>User not found.</p>";
  }
}